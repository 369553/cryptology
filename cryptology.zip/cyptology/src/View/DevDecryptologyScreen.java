package View;

import javax.swing.JPanel;

public class DevDecryptologyScreen extends JPanel {
    
}
