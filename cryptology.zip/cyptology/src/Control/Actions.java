package Control;

import Base.SystemSettings;
import Views.MainView;
import Views.OptionsScreen;
import Views.Theme;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class Actions implements ActionListener{
    MainView view ;
    OptionsScreen view_5th ;
    String path ;
    JOptionPane message ;
    
    public Actions (){
        
    }
    
    public Actions (MainView view){
        this.view = view;
    }
    
    public Actions ( OptionsScreen view ) {
        view_5th = view ;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if ( view != null ) {
            if ( e.getSource() == view.getButton_1st() ) {
                view.getFrame_main().getContentPane().removeAll();
                view.getFrame_main().add( view.getPanel_2nd(), BorderLayout.CENTER );
//                this.view.getFrame_main().add(this.view.getMovementPanel(),BorderLayout.WEST);
                //view.getFrame_main().setContentPane( view.getPanel_2nd() ) ;
                view.getPanel_2nd().getOpen_Text().requestFocus() ;
                view.getFrame_main().setVisible(true);
             }
            else if ( e.getSource() == view.getButton_2nd() ) {
                view.getFrame_main().getContentPane().removeAll();
                view.getFrame_main().setContentPane( view.getPanel_3rd() ) ;
             }
            else if ( e.getSource() == view.getButton_3rd() ) {
                view.getFrame_main().getContentPane().removeAll();
                view.getFrame_main().setContentPane( view.getPanel_4th() ) ;
            }
            else if ( e.getSource() == view.getButton_4th() ) {
                view.getFrame_main().getContentPane().removeAll();
                view.getFrame_main().add(view.getPanel_5th());
                //view.getFrame_main().setContentPane( view.getPanel_5th() ) ;
                view.getFrame_main().setVisible(true);
             }
        }
        
        else if ( view_5th != null ) {
            if ( e.getSource() == view_5th.getButton_1st() ){
                setSettings( view_5th ) ;
                if ( view_5th.getCheckBox_1st().isSelected() == true && SystemSettings.getSettings().getPATHPosition() == null ) {
                    message.showMessageDialog( view_5th, "Galiba rapor kayıt yeri seçmeyi unuttunuz!", "Küçük bir hata", JOptionPane.ERROR_MESSAGE );
                }
                else {
                    this.view = new MainView() ;
                    this.view.getFrame_main().getContentPane().removeAll();
                    this.view.getFrame_main().add(this.view.getPanel_panel(),BorderLayout.CENTER);
//                this.view.getFrame_main().add(this.view.getMovementPanel(),BorderLayout.WEST);
                    this.view.getFrame_main().setVisible(true);
                }
            }
            else if ( e.getSource() == view_5th.getButton_2nd() ) {
                view_5th.openChooser();
            }
            else if (e.getSource() == view_5th.getChooser() ) {
                getPath();
            }
            else if ( e.getSource() == view_5th.getCheckBox_1st() ) {
                if ( view_5th.getCheckBox_1st().isSelected() )
                    view_5th.getButton_2nd().setEnabled( true ) ;
                else
                    view_5th.getButton_2nd().setEnabled( false ) ;
            }
        }
    }
    
    private boolean setSettings( OptionsScreen view ) {
        boolean reports = view.getCheckBox_1st().isSelected() ;
        String theme = exportTheme ( view.getComboBox_2nd().getSelectedIndex() ) ;
        SystemSettings.getSettings().setReports( reports ) ;
        SystemSettings.getSettings().setLanguage( view.getComboBox_1st().getSelectedItem().toString() ) ;
        if ( reports == true ) {
            if ( path != null ) {
                SystemSettings.getSettings().setPATHPosition ( this.path ) ;
            }
            else {
                reports = false ; SystemSettings.getSettings().setReports( reports ) ; }
        }
        SystemSettings.getSettings().setThemeName ( theme ) ;
        SystemSettings.getSettings().setCurrentTheme( new Theme ( theme ) ) ;
        System.out.println( SystemSettings.getSettings().toString() ) ;
        return true ;
    }
    
    public void getPath () {
        if ( view_5th.getChooser().getSelectedFile() != null ) {
            path = view_5th.getChooser().getSelectedFile().getAbsolutePath() ;
            view_5th.getChooser().setSelectedFile( null ) ;
            System.out.println("path: "  + path ) ;
        }
    }
    
    public static String exportTheme ( int index ) {
        switch( index ){
            case 0: return "Standard" ;
            case 1: return "Alternative" ;
            case 2: return "Blue" ;
            case 3: return "Purple" ;
            case 4: return "Red" ;
            case 5: return "Gold" ;
            case 6: return "Special" ;
            case 7: return "Dark" ;
            default: return "Standard" ;
        }
    }
    
}
