package Control;

import Algorithms.Ceasar;
import Algorithms.Columnar;
import Algorithms.Polybius;
import Algorithms.Vigenere;
import Base.DataBase;
import Base.SystemSettings;
import Views.CryptScreen;
import Views.FinalScreen;
import Views.MainFrame;
import Views.ReqCeasar;
import Views.ReqPolybius;
import Views.ReqVigenere;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class CryptAction implements ActionListener {
    CryptScreen act ;
    ReqCeasar rc ;
    ReqVigenere rv ;
    ReqPolybius rp ;
    boolean change ;
    boolean con ;
    JOptionPane message ;
    
    public CryptAction ( CryptScreen act ) {
        this.act = act ;
    }
    
    public CryptAction ( ReqCeasar rc ) {
        this.rc = rc ;
}
    public CryptAction ( ReqVigenere rv ) {
        this.rv = rv ;
    }
    public CryptAction ( ReqPolybius rp ) {
        this.rp = rp ;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if ( act != null ) {
            if ( e.getSource() == act.getButton_1st() ) {
                    act.changeReqPanel();
                  //geçici çözüm  act.getSelect_Algh().setEnabled(false);
                    MainFrame.getFrame_Main().setVisible( true ) ;
            }
            else if ( e.getSource() == act.getSelect_Algh() ) {
                if ( act.getCurrent_algorithm().equals( act.getSelect_Algh().getSelectedItem().toString() ) )
                    change = false ;
                else
                    change = true ;
                if ( change == true ) {
                   act.setHints() ;
                   act.getOpen_Text().setText( "" ) ;
                }
                checkButton1st( act.getSelect_Algh().getSelectedItem().toString() ) ;
                act.setCurrent_algorithm( act.getSelect_Algh().getSelectedItem().toString() ) ;
                if ( MainFrame.getFrame_Main().getContentPane().getComponents().length == 4 ) {
                    if ( change != false ) {
                        act.refreshReq() ;
                        MainFrame.getFrame_Main().setVisible( true ) ;
                    }
                }
            }
            else if ( e.getSource() == act.getButton_2nd() ) {
                con  = true ;
                String currAlg = new String ( act.getCurrent_algorithm() ) ;
                if ( currAlg.equals( "VIGENERE" ) ) {
                    if ( act.getReqVigenere().getTextField1st().getText().length() != act.getOpen_Text().getText().length() ) {
                        con = false ;
                        message.showMessageDialog( act, "Girdiğiniz anahtar uzunluğu, açık metnin anahtar uzunluğuyla aynı olmalıdır!", "HATA", JOptionPane.ERROR_MESSAGE );
                    }
                }
                if ( con == true ) {
                    if ( SystemSettings.getSettings().getIsReports() == true )
                        ReportSystem.getReportManager().Reporting( currAlg ) ;
                    showLastScreen( currAlg ) ;
                    if ( SystemSettings.getSettings().getIsReports() == true )
                        try {
                            ReportSystem.getReportManager().Saving( currAlg ) ;
                        }
                        catch (IOException ex) {
                            Logger.getLogger(CryptAction.class.getName()).log(Level.SEVERE, null, ex);
                            System.exit(0);
                        }
                }
            }
        }
        else if ( rc != null ) {
            if ( e.getSource() == rc.getCBox_Lang() ) {
                Ceasar.getCeasar().changeAlphabet( rc.getCBox_Lang().getSelectedItem().toString() ) ;
                System.out.println("alfabeee");
                rc.changeSlider_1st();
                CryptScreen cr = (CryptScreen) MainFrame.getFrame_Main().getContentPane().getComponent( 2 );
                cr.getOpen_Text().setText( "" ) ;
            }
        }
        else if ( rv != null ) {//JAVADA COMPONENT NUMARALARI NASIL ATANIOR ARAŞTIR
            if ( e.getSource() == rv.getCBox_Lang() ) {
                Vigenere.getVigenere().changeAlphabet( rv.getCBox_Lang().getSelectedItem().toString() ) ;
                CryptScreen cr = (CryptScreen) MainFrame.getFrame_Main().getContentPane().getComponent( 2 );
                cr.getOpen_Text().setText( "" ) ;
                rv.getTextField1st().setText( "" ) ;
            }
        }
        else if ( rp != null ) {
            if ( e.getSource() == rp.getCBoxLang() ) {
                Polybius.getPolybius().changeAlphabet( rp.getCBoxLang().getSelectedItem().toString() ) ;
                CryptScreen cr = (CryptScreen) MainFrame.getFrame_Main().getContentPane().getComponent( 2 );
                cr.getOpen_Text().setText( "" ) ;
            }
        }
    
    }
    
    public void showLastScreen ( String algorithm ) {
        FinalScreen FScreen = new FinalScreen( algorithm ) ;
        MainFrame.getFrame_Main().getContentPane().remove( 2 ) ;
        if ( MainFrame.getFrame_Main().getContentPane().getComponentCount() == 3 )
            MainFrame.getFrame_Main().getContentPane().remove( 2 ) ;
        MainFrame.getFrame_Main().add(FScreen, BorderLayout.CENTER ) ;
        MainFrame.getFrame_Main().setVisible( true ) ;
            if ( algorithm.equals( "CEASAR" ) ) {
                FScreen.WriteInfs( new String[] { new String ( "ALFABE: " + Ceasar.getCeasar().getAlphabet().getName() ), new String( "Kaydırma miktarı: " + Ceasar.getCeasar().getNum_shift() ), new String( "Şifreli metin: " + Ceasar.getCeasar().crypting( act.getOpen_Text().getText() ) ) } ) ;
  /*HintTextlerin tamamını DataBase'den çek*/
            }
            else if ( algorithm.equals( "COLUMNAR" ) ) {
                char[][] text = Columnar.getColumnar().crypting( act.getOpen_Text().getText() ) ;
                int length = text.length ;
                String[] textStr ;
                textStr = new String[ length ] ;
                for ( int i = 0 ; i < length ; i++ ) {
                    textStr[i] = new String ( text[i] ) ;
                }
                FScreen.WriteInfs( textStr ) ;
            }
            else if ( algorithm.equals( "VIGENERE" ) ) {
                FScreen.WriteInfs( new String[] { new String ( "ALFABE: " + Vigenere.getVigenere().getAlphabet().getName() ), new String ( "ANAHTAR: " + act.getReqVigenere().getTextField1st().getText() ), new String( "Şifreli metin: " + Vigenere.getVigenere().crypting( act.getOpen_Text().getText(), act.getReqVigenere().getTextField1st().getText() ) ) } ) ;
            }
             act.getHintText().setText( DataBase.getDatabase().getHints( algorithm, true ) ) ;
        MainFrame.getFrame_Main().setVisible( true ) ;
    }
    
    public void checkButton1st ( String algorithm ) {
        switch ( algorithm ) {
            case "CEASAR": { act.getButton_1st().setEnabled( true ) ; MainFrame.getFrame_Main().setVisible( true ) ; break ; }
            case "COLUMNAR": { act.getButton_1st().setEnabled( false ) ; MainFrame.getFrame_Main().setVisible( true ) ; break ; }
            case "VIGENERE": { act.getButton_1st().setEnabled( true ) ; MainFrame.getFrame_Main().setVisible( true ) ; break ; }
            //case ...
        }
    }
    
}
