package Control;

import Views.CryptScreen;
import Views.MainFrame;
import Views.MainView;
import Views.MovementPanel;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class BackAction implements ActionListener {
    MovementPanel act ;
    
    public BackAction ( MovementPanel act ) {
        this.act = act ;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if ( e.getSource() == act.getButton_back() ) {
            if ( act.getBackComponentName().equals( "MainView" ) ) {
               MainFrame.getFrame_Main().getContentPane().removeAll() ;
               MainView view = new MainView() ;
               MainFrame.getFrame_Main().add( view.getPanel_panel(),BorderLayout.CENTER ) ;
               MainFrame.getFrame_Main().setVisible( true ) ;
            }
            else if (  act.getBackComponentName().equals( "CryptScreen" ) ) {
                MainFrame.getFrame_Main().getContentPane().removeAll() ;
                CryptScreen cryptView = new CryptScreen() ;//Geri döndüğünde algoritma ayarları değiştirilmeli vs. üzerinde düşün ve gerekeni yap
                cryptView.getOpen_Text().requestFocus() ;
                MainFrame.getFrame_Main().add( cryptView,BorderLayout.CENTER ) ;
                MainFrame.getFrame_Main().setVisible( true ) ;
            }
        }
    
    }
    
}
