package Algorithms;


public class PicketFence {
    
    public String[] crypting ( String open_Message ) {
        StringBuilder message, crypt_Message, crypt_Message2;
        int index, index2=0, index3=0;
        message = new StringBuilder ( open_Message );
        crypt_Message = new StringBuilder ();
        crypt_Message.setLength((message.length()/2)+1);
        crypt_Message2 = new StringBuilder();
        crypt_Message2.setLength((message.length()/2)+1);
        
        for ( index = 0 ; index < message.length() ; index++ ) {
            if ( index % 2 == 0 ) {
                crypt_Message.setCharAt(index2, message.charAt(index));
                index2++;
            }
            else{
                crypt_Message2.setCharAt(index3, message.charAt(index));
                index3++;
            }
        }
        crypt_Message.setLength(index2);
        crypt_Message2.setLength(index3);
        return new String[] {new String(crypt_Message), new String(crypt_Message2)};
    }
    
    public String decrypting ( String[] crypt_Message ) {
        int index2=0, length = crypt_Message[0].length() + crypt_Message[1].length();
        StringBuilder openMessage = new StringBuilder();
        openMessage.setLength(length+1);
        if ( length %2 != 0){
            for ( int index = 0 ; index < length ; index++ ) {
                if ( index % 2 == 0 ){
                    openMessage.setCharAt(index, crypt_Message[0].charAt(index2));
                    index2++;
                }
                else{
                    openMessage.setCharAt(index, crypt_Message[1].charAt(index - index2));
                }
            }
        }
        return new String(openMessage);
    }
    
}