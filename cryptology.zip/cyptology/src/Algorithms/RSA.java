package Algorithms;

public class RSA {
    
    RSA ( String key ) {
        
    }
    
    
    
    
    public RSA getRSA ( String key ) {
        
        
        return new RSA(key) ;
    }
}
