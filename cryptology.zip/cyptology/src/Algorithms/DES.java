package Algorithms;

public class DES {
        boolean [] key ;
    public DES ( boolean [] key ) {
        if ( key.length == 64 )
            this.key = key ;
    }
    public DES ( String key ) {
        if ( key.length() == 4 ){
            this.key = merge( new boolean [] []  { convert_to_bits_for_char ( key.charAt(0) )  ,  convert_to_bits_for_char ( key.charAt(1) )  ,  convert_to_bits_for_char ( key.charAt(2) )  ,  convert_to_bits_for_char ( key.charAt(3) )  } ) ;
        }
    }
    public String crypting ( String open_Message ) {
        return crypting_Main ( open_Message , true ) ;
    }
    public String crypting_Main ( String open_Message , boolean is_crypting ) {
        int count = 0 , length ;
        boolean [] message ;
        boolean [] temp ;
        temp = new boolean [32] ;
        boolean [][] block_in_cycle ;
        message = new boolean [open_Message.length() * 16] ;
        for ( int index = 0 ; index < open_Message.length() ; index++ ) {
           /*int a çevrildiğinde öndeki sıfırlar gidiyor mu?*/ boolean[] current_character = convert_to_bits_for_char ( (int) ( open_Message.charAt (index) ) ) ;
/*BAŞARILI*//*TEST = CORRECT*/ //          System.out.println("\n şu an karakter : " + open_Message.charAt(index) + "\n şu anki karakterin ascii kodu: " + ((int) open_Message.charAt(index)) + "\nmesajın boolean hali: " ) ;
/*BAŞARILI*//*TEST = CORRECT*/ //print_boolean_matrix(current_character) ;
            for ( int index2 = 0 ; index2 < 16 ; index2++ ) {
                message [count] = current_character[index2];
                //System.out.println("\ncurrent_character[" + count + "] : " + current_character[index2]);
                count = count + 1;
            }
        }
/*BAŞARILI*//*TEST : Mesaj, bitsel ascii kodu doğru aktarılmış mı*///System.out.println("\n mesajın ikilik sayı sisteminde ascii kodu: ");
/*BAŞARILI*//*TEST : DEVAMI*///            print_boolean_matrix(message);
/*TEST : Mesaj, tüm karakterler alınmış mı, mesaj uzunluğu doğru mu?*///System.out.println("\nmesajın uzunluğu : " + (message.length / 16) );
        boolean [] [] message_blocks = divide( message, 64 ) ;
        length = message_blocks.length ;
/*BAŞARILI*//*TEST = length (mesaj parça sayısı) doğru mu*///System.out.println("\nmesaj " + length + "parçadan oluşuyor");
        boolean [] [] crypt_blocks = message_blocks ;
        boolean [] [] sessions_Keys ;
        sessions_Keys = calculating_Key ( getKey() ) ;
        /*if ( is_crypting == false )//BU İŞLEM YAPILMALI MI, YAPILMAZSA NE OLUR?
            sessions_Keys = reverse ( sessions_Keys ) ;*/
        for ( int index = 0 ; index < length; index++ ) {
//            crypt_blocks [index] = initial_permutating ( message_blocks [index] ) ;
                block_in_cycle = divide ( crypt_blocks [index], 32 );
/*BAŞARILI*//*TEST : döngü dizisinin boyutunun kontrolü*///System.out.println("\nblock_in_cycle : [" + block_in_cycle.length + "][" + block_in_cycle[0].length + "]");
            for ( int index2 = 0 ; index2 < 16 ; index2++ ) {
                temp = block_in_cycle [1] ;
                block_in_cycle [1] = function_f ( block_in_cycle [1] , sessions_Keys [index] ) ;
                block_in_cycle [1] = p_boxing (block_in_cycle [1] ) ;
                block_in_cycle [1] = exor ( block_in_cycle [0] , block_in_cycle [1] ) ;
                block_in_cycle [0] = temp ;
            }
            crypt_blocks [index] = merge ( block_in_cycle ) ;
            //print_double_boolean_matrix(crypt_blocks);
 //           crypt_blocks [index] = final_permutating ( crypt_blocks [index] ) ;
        }
        //System.out.println("cryptblock.length = " + length ) ;
        StringBuilder cryptMessage ;
        int returrr = 0 ;
        cryptMessage = new StringBuilder (length * 4 ) ;
        boolean[][] tempChars;
        for ( int index = 0 ; index < length ; index++ ) {
/* int a dönüşünce kayıp var mı ?*/            //returrr = convert_to_int (crypt_blocks[index] ) ;BU KONTROLÜ YAPMAN GEREKİYORSA YAP, ANCAK int VERİ TİPİ 64 BİTLİK SAYIYI İFADE EDEMEZ
            tempChars = divide (crypt_blocks[index],16);
/*BAŞARILI*//*TEST : tempChar BOYUT KONTROLÜ*///System.out.println("\ntempchar : [" + tempChar.length + "][" + tempChar[0].length + "]");
            
            for ( int indexx = 0; indexx < 4; indexx++){
/*UNICODE kodunu bulmaya gonder*/       //     cryptMessage.append( Integer./*önceki hali: toHexString*//*yeni hali*/toString (convert_to_int ( tempChars[indexx] ) ) ) ;
                System.out.println("\n" + indexx + ". karakter = " + convert_to_int ( tempChars[indexx] ));
                char tempChar;
                tempChar = (char) convert_to_int ( tempChars[indexx] );
                cryptMessage.append(tempChar);
            }
        }
        //System.out.println("returrr : " + returrr ) ;
        return new String ( cryptMessage ) ;
    }
    
    public String decrypting ( String cryptMessage ) {
        return  crypting_Main ( cryptMessage , false) ;
    }
    
    public boolean [] [] reverse ( boolean [] [] value ) {
        short length = (short) ( value.length - 1 ) ;
        boolean [] [] returnValue ;
        returnValue = new boolean [value.length] [value[0].length] ;
        for ( int index = 0 ; index < value.length ; index++ ) {
            returnValue [index] = value [length - index] ;
        }
        return returnValue ;
    }
    
    public boolean [] p_boxing (boolean [] value ) {
        boolean [] return_Value ;
        boolean [] [] map = designation_Map () ;
        return_Value = new boolean [32] ;
        for ( int index = 0 ; index < 32 ; index++ ) {
            return_Value [index] = value [convert_to_int(map [index])] ; 
        }
        return return_Value ;
    }
    
    public boolean [] [] designation_Map () {
        boolean [] [] map ;
        map = new boolean [32] [5] ;
        convert_to_bits_for_5bayt ( 16 ) ; map [1] = convert_to_bits_for_5bayt ( 7 ) ; map [2] = convert_to_bits_for_5bayt ( 20 ) ; map [3] = convert_to_bits_for_5bayt ( 21 ) ; map [4] = convert_to_bits_for_5bayt ( 29 ) ;map [5] = convert_to_bits_for_5bayt ( 12 ) ; map [6] = convert_to_bits_for_5bayt ( 28 ) ; map [7] = convert_to_bits_for_5bayt ( 17 ) ; map [8] = convert_to_bits_for_5bayt ( 1 ) ; map [9] = convert_to_bits_for_5bayt ( 15 ) ;map [10] = convert_to_bits_for_5bayt ( 23 ) ; map [11] = convert_to_bits_for_5bayt ( 26 ) ; map [12] = convert_to_bits_for_5bayt ( 5 ) ; map [13] = convert_to_bits_for_5bayt ( 18 ) ; map [14] = convert_to_bits_for_5bayt ( 31 ) ;map [15] = convert_to_bits_for_5bayt ( 10 ) ; map [16] = convert_to_bits_for_5bayt ( 2 ) ; map [17] = convert_to_bits_for_5bayt ( 8 ) ;map [18] = convert_to_bits_for_5bayt ( 24 ) ; map [19] = convert_to_bits_for_5bayt ( 14 ) ; map [20] = convert_to_bits_for_5bayt ( 32 ) ; map [21] = convert_to_bits_for_5bayt ( 27 ) ; map [22] = convert_to_bits_for_5bayt ( 3 ) ;map [23] = convert_to_bits_for_5bayt ( 9 ) ; map [24] = convert_to_bits_for_5bayt ( 19 ) ; map [25] = convert_to_bits_for_5bayt ( 13 ) ;map [26] = convert_to_bits_for_5bayt ( 30 ) ; map [27] = convert_to_bits_for_5bayt ( 6 ) ; map [28] = convert_to_bits_for_5bayt ( 22 ) ;map [29] = convert_to_bits_for_5bayt ( 11 ) ; map [30] = convert_to_bits_for_5bayt ( 4 ) ; map [31] = convert_to_bits_for_5bayt ( 25 ) ; 
        return map ;
    }
    
    public boolean [] [] calculating_Key ( boolean [] key ) { // !KONTROL EDİLDİ : UYGUN
        boolean [] [] leftRightKey = divide ( non_Parity_Key(key) , 28 ) ;
        boolean [] [] sessionKeys ;
        boolean [] [] temp ;
        sessionKeys = new boolean [16] [48] ;
        temp = new boolean [16] [48] ;
/*BAŞARILI*//*TEST : BOYUT KONTROLÜ*///        System.out.println("leftRightKey = ["+ leftRightKey.length + "] [" + leftRightKey[0].length + "]\nsessionKeys : [" + sessionKeys.length + "][" + sessionKeys[0].length + "]");
/*BAŞARILI*//*TEST : BOYUT KONTROLÜ*///        System.out.println("\ntemp: [" + temp.length + "][" + temp[0].length + "]");
        for ( int index = 0 ; index < 16 ; index++ ) {
            if ( index == 0 || index == 1 || index == 8 || index == 15 ){
                leftRightKey[0] = shifting ( leftRightKey[0] , 1 ) ;
                leftRightKey[1] = shifting ( leftRightKey[1] , 1 ) ;
            }
            else {
                leftRightKey[0] = shifting ( leftRightKey[0] , 2 ) ;
                leftRightKey[1] = shifting ( leftRightKey[1] , 2 ) ;
            }
            temp = leftRightKey ;
            sessionKeys [index] = takeMiddle ( temp ) ;
        }
        return sessionKeys ;
    }
    
    public boolean [] takeMiddle ( boolean [] [] value ) {//KONTROL EDİLDİ: UYGUN
        int count = 0 ;
        boolean [] returnValue ; 
        returnValue = new boolean [48] ;
        for ( int index = 4 ; index < 28 ; index++ ) {
            returnValue [count] = value [0] [index] ;
            count++ ;
        }
        for ( int index = 0 ; index < 24 ; index++ ) {
            returnValue [count] = value [1] [index] ;
            count++ ;
        }
/*BAŞARILI*//*TEST : Ortadaki mi alınıyor?*/// print_boolean_matrix(merge(value)); print_boolean_matrix(returnValue);
/*BAŞARILI*//*TEST : Session keys sayısı ve uzunluğu*///System.out.println("\nsessionKeys yazdırılıyor...");print_boolean_matrix(returnValue);
        return returnValue ;
    }
    
    public boolean [] shifting ( boolean [] value , int shift_number) {//KONTROL EDİLDİ: UYGUN
        int length = value.length ;
        boolean [] returnValue ;
        returnValue = new boolean [length] ;
        for ( int index = length -1 ; index >= 0 ; index-- ) {
            if ( index - shift_number < 0 )
                returnValue [index] = value [index + length - shift_number] ;
            else
                returnValue [index] = value [index - shift_number] ;
        }
    return returnValue ;
    }
    
    public boolean [] non_Parity_Key ( boolean [] key ) {
        boolean [] [] non_parity_key ;
        boolean [] [] part_key = divide ( key , 8 ) ;
        non_parity_key = new boolean [8] [7] ;
        for ( int index = 0 ; index < 8 ; index++ ) {
            for ( int index2 = 0 ; index2 < 7 ; index2++ ) {
                non_parity_key [index] [index2] = part_key [index] [index2] ;
            }
        }
        return merge(non_parity_key) ;
    }
    
    public boolean [] initial_permutating ( boolean [] value ) {
        
        
        return new boolean[2];
    }
    
    public boolean [] final_permutating ( boolean [] value ) {
        
        
        return new boolean [2] ;
    }
    
    public boolean [] merge ( boolean [] [] value ) { // KONTROL EDİLDİ : UYGUN
        int length_of_lines = value.length , length_of_blocks = value [0].length , count = 0 ;
        boolean [] return_Value ;
        return_Value = new boolean [length_of_lines * length_of_blocks] ;
        for ( int index = 0 ; index <  length_of_lines ; index++ ) {
            for ( int index2 = 0 ; index2 < length_of_blocks ; index2++ ) {
                return_Value [count] = value [index] [index2] ;
                count += 1 ;
            }
        }
        return return_Value ;
    }
    
    public boolean [] function_f ( boolean [] message , boolean [] key ) { 
        boolean [] rendering ;
        rendering = expansion ( message ) ;
/*BAŞARILI*//*TEST : expansion sonucu uzunluk kontrol*///System.out.println("\nexpansion sonu:" + rendering.length);
        rendering = exor ( rendering , key ) ;
        return substitution ( rendering ) ;
    }
    
    public boolean [] expansion ( boolean [] value ) {
        boolean [] large ;
        large = new boolean [48] ;
        large[0] = value [ 31 ] ; large[1] = value [ 0 ] ; large[2] = value [ 1 ] ;large[3] = value [ 2 ] ; large[4] = value [ 3 ] ; large[5] = value [ 4 ] ; large[6] = value [ 3 ] ; large[7] = value [ 4 ] ; large[8] = value [ 5 ] ; large[9] = value [ 6 ] ; 
        large[10] = value [ 7 ] ; large[11] = value [ 8 ] ; large[12] = value [ 7 ] ; large[13] = value [ 8 ] ; large[14] = value [ 9 ] ; large[15] = value [ 10 ] ; large[16] = value [ 11 ] ; large[17] = value [ 12 ] ; large[18] = value [ 11 ] ; large[19] = value [ 12 ] ; 
        large[20] = value [ 13 ] ; large[21] = value [ 14 ] ; large[22] = value [ 15 ] ; large[23] = value [ 16 ] ; large[24] = value [ 15 ] ; large[25] = value [ 16 ] ; large[26] = value [ 17 ] ; large[27] = value [ 18 ] ; large[28] = value [ 19 ] ; large[29] = value [ 20 ] ; 
        large[30] = value [ 19 ] ; large[31] = value [ 20 ] ; large[32] = value [ 21 ] ; large[33] = value [ 22 ] ; large[34] = value [ 23 ] ; large[35] = value [ 24 ] ; large[36] = value [ 23 ] ; large[37] = value [ 24 ] ; large[38] = value [ 25 ] ; large[39] = value [ 26 ] ; 
        large[40] = value [ 27 ] ; large[41] = value [ 28 ] ; large[42] = value [ 27 ] ; large[43] = value [ 28 ] ; large[44] = value [ 29 ] ; large[45] = value [ 30 ] ; large[46] = value [ 31 ] ; large[47] = value [ 0 ] ;
        return large ;
    }
    
    public boolean [] [] divide ( boolean [] block , int target_size ) { //KONTROL EDİLDİ : UYGUN
        boolean [] [] return_Value ;
        int length , count = 0 , block_length = block.length ;
        if ( ( block.length  % target_size ) == 0 )
            length = ( block.length / target_size )  ;
        else
            length = ( block.length / target_size ) + 1 ;
        return_Value = new boolean [ length ] [ target_size ] ;
        for ( int index = 0 ; index < length ; index++ ) {
            for ( int index2 = 0 ; index2 < target_size ; index2++ ) {
                if ( count < block_length )
                    return_Value [index] [index2] = block [count] ;
                else
                    return_Value [index] [index2] = false ;
                count++ ;
            }
        }
        
        return return_Value ;
    }
    
    public boolean [] substitution ( boolean [] value ) {//SIKINTI anahtarın ters çevrilmesinde veya bu fonksiyonda, ya da işlem hatası olabilir, ya da ....
        boolean [] [] [] [] sboxs ;
        boolean [] zip_Value ;
        boolean [] [] rendering_Value ;
        rendering_Value = divide ( value , 6 ) ;
        boolean [] [] zip_Valuepart ;
        zip_Valuepart = new boolean [8] [4] ;
//HATA VERİRSE BU SATIRI AÇ zip_Value = new boolean [32] ;
        sboxs = designation_sboxs () ;
        for ( int index = 0 ; index < 8 ; index++ ) {
            int line = convert_to_int (new boolean [] {rendering_Value[index][0] ,rendering_Value [index][5] } ) ;
            int col = convert_to_int(new boolean [] { rendering_Value [index] [1] , rendering_Value [index] [2] , rendering_Value [index] [3] , rendering_Value [index] [4] } ) ;
            zip_Valuepart [index] = sboxs [index] [line] [col] ;
        }
        zip_Value = merge( zip_Valuepart ) ;
/*BAŞARILI*//*TEST : SIKIŞTIRMA SONUCU BOYUT KONTROL*///System.out.println("\nzipValue.length : " + zip_Value.length);
        return zip_Value ;
    }
    
    public boolean [] [] [] [] designation_sboxs () {
        boolean sboxs [] [] [] [] ;
        sboxs= new boolean [8] [4] [16] [4] ;
        sboxs [0] [0] [0] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [0] [0] [1] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [0] [0] [2] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [0] [0] [3] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [0] [0] [4] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [0] [0] [5] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [0] [0] [6] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [0] [0] [7] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [0] [0] [8] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [0] [0] [9] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [0] [0] [10] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [0] [0] [11] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [0] [0] [12] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [0] [0] [13] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [0] [0] [14] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [0] [0] [15] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [0] [1] [0] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [0] [1] [1] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [0] [1] [2] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [0] [1] [3] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [0] [1] [4] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [0] [1] [5] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [0] [1] [6] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [0] [1] [7] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [0] [1] [8] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [0] [1] [9] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [0] [1] [10] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [0] [1] [11] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [0] [1] [12] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [0] [1] [13] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [0] [1] [14] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [0] [1] [15] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [0] [2] [0] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [0] [2] [1] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [0] [2] [2] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [0] [2] [3] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [0] [2] [4] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [0] [2] [5] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [0] [2] [6] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [0] [2] [7] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [0] [2] [8] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [0] [2] [9] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [0] [2] [10] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [0] [2] [11] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [0] [2] [12] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [0] [2] [13] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [0] [2] [14] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [0] [2] [15] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [0] [3] [0] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [0] [3] [1] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [0] [3] [2] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [0] [3] [3] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [0] [3] [4] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [0] [3] [5] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [0] [3] [6] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [0] [3] [7] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [0] [3] [8] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [0] [3] [9] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [0] [3] [10] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [0] [3] [11] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [0] [3] [12] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [0] [3] [13] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [0] [3] [14] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [0] [3] [15] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [1] [0] [0] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [1] [0] [1] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [1] [0] [2] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [1] [0] [3] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [1] [0] [4] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [1] [0] [5] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [1] [0] [6] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [1] [0] [7] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [1] [0] [8] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [1] [0] [9] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [1] [0] [10] = convert_to_bits_for_4bayt (2  ) ; sboxs [1] [0] [11] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [1] [0] [12] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [1] [0] [13] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [1] [0] [14] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [1] [0] [15] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [1] [1] [0] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [1] [1] [1] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [1] [1] [2] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [1] [1] [3] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [1] [1] [4] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [1] [1] [5] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [1] [1] [6] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [1] [1] [7] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [1] [1] [8] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [1] [1] [9] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [1] [1] [10] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [1] [1] [11] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [1] [1] [12] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [1] [1] [13] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [1] [1] [14] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [1] [1] [15] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [1] [2] [0] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [1] [2] [1] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [1] [2] [2] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [1] [2] [3] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [1] [2] [4] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [1] [2] [5] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [1] [2] [6] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [1] [2] [7] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [1] [2] [8] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [1] [2] [9] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [1] [2] [10] = convert_to_bits_for_4bayt (12  ) ; sboxs [1] [2] [11] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [1] [2] [12] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [1] [2] [13] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [1] [2] [14] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [1] [2] [15] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [1] [3] [0] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [1] [3] [1] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [1] [3] [2] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [1] [3] [3] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [1] [3] [4] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [1] [3] [5] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [1] [3] [6] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [1] [3] [7] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [1] [3] [8] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [1] [3] [9] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [1] [3] [10] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [1] [3] [11] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [1] [3] [12] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [1] [3] [13] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [1] [3] [14] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [1] [3] [15] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [2] [0] [0] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [2] [0] [1] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [2] [0] [2] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [2] [0] [3] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [2] [0] [4] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [2] [0] [5] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [2] [0] [6] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [2] [0] [7] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [2] [0] [8] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [2] [0] [9] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [2] [0] [10] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [2] [0] [11] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [2] [0] [12] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [2] [0] [13] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [2] [0] [14] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [2] [0] [15] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [2] [1] [0] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [2] [1] [1] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [2] [1] [2] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [2] [1] [3] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [2] [1] [4] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [2] [1] [5] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [2] [1] [6] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [2] [1] [7] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [2] [1] [8] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [2] [1] [9] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [2] [1] [10] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [2] [1] [11] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [2] [1] [12] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [2] [1] [13] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [2] [1] [14] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [2] [1] [15] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [2] [2] [0] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [2] [2] [1] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [2] [2] [2] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [2] [2] [3] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [2] [2] [4] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [2] [2] [5] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [2] [2] [6] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [2] [2] [7] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [2] [2] [8] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [2] [2] [9] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [2] [2] [10] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [2] [2] [11] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [2] [2] [12] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [2] [2] [13] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [2] [2] [14] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [2] [2] [15] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [2] [3] [0] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [2] [3] [1] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [2] [3] [2] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [2] [3] [3] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [2] [3] [4] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [2] [3] [5] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [2] [3] [6] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [2] [3] [7] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [2] [3] [8] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [2] [3] [9] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [2] [3] [10] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [2] [3] [11] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [2] [3] [12] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [2] [3] [13] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [2] [3] [14] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [2] [3] [15] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [3] [0] [0] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [3] [0] [1] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [3] [0] [2] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [3] [0] [3] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [3] [0] [4] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [3] [0] [5] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [3] [0] [6] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [3] [0] [7] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [3] [0] [8] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [3] [0] [9] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [3] [0] [10] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [3] [0] [11] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [3] [0] [12] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [3] [0] [13] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [3] [0] [14] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [3] [0] [15] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [3] [1] [0] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [3] [1] [1] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [3] [1] [2] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [3] [1] [3] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [3] [1] [4] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [3] [1] [5] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [3] [1] [6] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [3] [1] [7] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [3] [1] [8] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [3] [1] [9] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [3] [1] [10] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [3] [1] [11] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [3] [1] [12] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [3] [1] [13] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [3] [1] [14] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [3] [1] [15] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [3] [2] [0] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [3] [2] [1] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [3] [2] [2] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [3] [2] [3] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [3] [2] [4] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [3] [2] [5] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [3] [2] [6] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [3] [2] [7] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [3] [2] [8] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [3] [2] [9] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [3] [2] [10] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [3] [2] [11] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [3] [2] [12] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [3] [2] [13] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [3] [2] [14] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [3] [2] [15] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [3] [3] [0] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [3] [3] [1] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [3] [3] [2] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [3] [3] [3] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [3] [3] [4] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [3] [3] [5] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [3] [3] [6] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [3] [3] [7] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [3] [3] [8] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [3] [3] [9] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [3] [3] [10] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [3] [3] [11] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [3] [3] [12] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [3] [3] [13] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [3] [3] [14] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [3] [3] [15] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [4] [0] [0] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [4] [0] [1] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [4] [0] [2] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [4] [0] [3] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [4] [0] [4] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [4] [0] [5] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [4] [0] [6] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [4] [0] [7] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [4] [0] [8] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [4] [0] [9] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [4] [0] [10] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [4] [0] [11] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [4] [0] [12] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [4] [0] [13] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [4] [0] [14] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [4] [0] [15] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [4] [1] [0] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [4] [1] [1] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [4] [1] [2] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [4] [1] [3] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [4] [1] [4] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [4] [1] [5] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [4] [1] [6] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [4] [1] [7] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [4] [1] [8] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [4] [1] [9] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [4] [1] [10] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [4] [1] [11] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [4] [1] [12] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [4] [1] [13] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [4] [1] [14] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [4] [1] [15] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [4] [2] [0] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [4] [2] [1] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [4] [2] [2] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [4] [2] [3] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [4] [2] [4] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [4] [2] [5] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [4] [2] [6] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [4] [2] [7] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [4] [2] [8] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [4] [2] [9] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [4] [2] [10] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [4] [2] [11] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [4] [2] [12] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [4] [2] [13] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [4] [2] [14] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [4] [2] [15] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [4] [3] [0] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [4] [3] [1] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [4] [3] [2] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [4] [3] [3] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [4] [3] [4] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [4] [3] [5] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [4] [3] [6] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [4] [3] [7] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [4] [3] [8] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [4] [3] [9] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [4] [3] [10] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [4] [3] [11] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [4] [3] [12] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [4] [3] [13] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [4] [3] [14] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [4] [3] [15] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [5] [0] [0] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [5] [0] [1] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [5] [0] [2] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [5] [0] [3] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [5] [0] [4] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [5] [0] [5] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [5] [0] [6] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [5] [0] [7] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [5] [0] [8] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [5] [0] [9] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [5] [0] [10] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [5] [0] [11] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [5] [0] [12] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [5] [0] [13] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [5] [0] [14] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [5] [0] [15] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [5] [1] [0] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [5] [1] [1] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [5] [1] [2] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [5] [1] [3] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [5] [1] [4] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [5] [1] [5] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [5] [1] [6] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [5] [1] [7] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [5] [1] [8] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [5] [1] [9] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [5] [1] [10] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [5] [1] [11] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [5] [1] [12] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [5] [1] [13] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [5] [1] [14] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [5] [1] [15] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [5] [2] [0] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [5] [2] [1] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [5] [2] [2] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [5] [2] [3] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [5] [2] [4] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [5] [2] [5] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [5] [2] [6] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [5] [2] [7] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [5] [2] [8] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [5] [2] [9] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [5] [2] [10] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [5] [2] [11] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [5] [2] [12] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [5] [2] [13] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [5] [2] [14] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [5] [2] [15] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [5] [3] [0] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [5] [3] [1] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [5] [3] [2] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [5] [3] [3] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [5] [3] [4] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [5] [3] [5] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [5] [3] [6] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [5] [3] [7] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [5] [3] [8] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [5] [3] [9] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [5] [3] [10] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [5] [3] [11] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [5] [3] [12] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [5] [3] [13] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [5] [3] [14] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [5] [3] [15] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [6] [0] [0] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [6] [0] [1] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [6] [0] [2] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [6] [0] [3] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [6] [0] [4] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [6] [0] [5] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [6] [0] [6] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [6] [0] [7] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [6] [0] [8] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [6] [0] [9] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [6] [0] [10] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [6] [0] [11] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [6] [0] [12] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [6] [0] [13] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [6] [0] [14] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [6] [0] [15] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [6] [1] [0] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [6] [1] [1] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [6] [1] [2] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [6] [1] [3] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [6] [1] [4] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [6] [1] [5] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [6] [1] [6] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [6] [1] [7] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [6] [1] [8] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [6] [1] [9] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [6] [1] [10] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [6] [1] [11] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [6] [1] [12] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [6] [1] [13] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [6] [1] [14] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [6] [1] [15] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [6] [2] [0] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [6] [2] [1] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [6] [2] [2] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [6] [2] [3] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [6] [2] [4] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [6] [2] [5] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [6] [2] [6] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [6] [2] [7] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [6] [2] [8] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [6] [2] [9] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [6] [2] [10] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [6] [2] [11] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [6] [2] [12] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [6] [2] [13] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [6] [2] [14] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [6] [2] [15] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [6] [3] [0] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [6] [3] [1] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [6] [3] [2] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [6] [3] [3] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [6] [3] [4] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [6] [3] [5] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [6] [3] [6] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [6] [3] [7] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [6] [3] [8] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [6] [3] [9] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [6] [3] [10] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [6] [3] [11] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [6] [3] [12] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [6] [3] [13] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [6] [3] [14] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [6] [3] [15] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [7] [0] [0] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [7] [0] [1] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [7] [0] [2] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [7] [0] [3] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [7] [0] [4] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [7] [0] [5] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [7] [0] [6] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [7] [0] [7] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [7] [0] [8] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [7] [0] [9] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [7] [0] [10] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [7] [0] [11] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [7] [0] [12] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [7] [0] [13] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [7] [0] [14] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [7] [0] [15] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [7] [1] [0] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [7] [1] [1] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [7] [1] [2] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [7] [1] [3] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [7] [1] [4] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [7] [1] [5] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [7] [1] [6] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [7] [1] [7] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [7] [1] [8] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [7] [1] [9] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [7] [1] [10] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [7] [1] [11] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [7] [1] [12] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [7] [1] [13] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [7] [1] [14] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [7] [1] [15] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [7] [2] [0] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [7] [2] [1] = convert_to_bits_for_4bayt ( 11 ) ; sboxs [7] [2] [2] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [7] [2] [3] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [7] [2] [4] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [7] [2] [5] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [7] [2] [6] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [7] [2] [7] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [7] [2] [8] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [7] [2] [9] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [7] [2] [10] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [7] [2] [11] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [7] [2] [12] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [7] [2] [13] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [7] [2] [14] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [7] [2] [15] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [7] [3] [0] = convert_to_bits_for_4bayt ( 2 ) ; sboxs [7] [3] [1] = convert_to_bits_for_4bayt ( 1 ) ; sboxs [7] [3] [2] = convert_to_bits_for_4bayt ( 14 ) ; sboxs [7] [3] [3] = convert_to_bits_for_4bayt ( 7 ) ; sboxs [7] [3] [4] = convert_to_bits_for_4bayt ( 4 ) ; sboxs [7] [3] [5] = convert_to_bits_for_4bayt ( 10 ) ; sboxs [7] [3] [6] = convert_to_bits_for_4bayt ( 8 ) ; sboxs [7] [3] [7] = convert_to_bits_for_4bayt ( 13 ) ; sboxs [7] [3] [8] = convert_to_bits_for_4bayt ( 15 ) ; sboxs [7] [3] [9] = convert_to_bits_for_4bayt ( 12 ) ; sboxs [7] [3] [10] = convert_to_bits_for_4bayt ( 9 ) ; sboxs [7] [3] [11] = convert_to_bits_for_4bayt ( 0 ) ; sboxs [7] [3] [12] = convert_to_bits_for_4bayt ( 3 ) ; sboxs [7] [3] [13] = convert_to_bits_for_4bayt ( 5 ) ; sboxs [7] [3] [14] = convert_to_bits_for_4bayt ( 6 ) ; sboxs [7] [3] [15] = convert_to_bits_for_4bayt ( 11 ) ; 
        return sboxs;
    }
    
    public boolean [] convert_to_bits_for_char ( int entry ) { //KONTROL EDİLDİ : UYGUN
        int value = entry , mod = 0 ;
        boolean [] return_value ;
        return_value = new boolean [16] ;
        for ( int index = 0 ; index < 16 ; index++ ) {
            mod = (value % 2) ;
            if ( mod == 0 )
                return_value [index] = false ;
            else
                return_value [index] = true ;
            value /= 2 ;
        }
        return return_value ;
    }
       
    public boolean [] convert_to_bits_for_4bayt ( int entry ) { //KONTROL EDİLDİ : UYGUN
        int value = entry , mod = 0 ;
        boolean [] return_value ;
        return_value = new boolean [4] ;
        for ( int index = 0 ; index < 4 ; index++ ) {
            mod = (value % 2) ;
            if ( mod == 0 )
                return_value [index] = false ;
            else
                return_value [index] = true ;
            value /= 2 ;
        }
        return return_value ;
    }
    
    public boolean [] convert_to_bits_for_5bayt ( int entry ) { //KONTROL EDİLDİ : UYGUN
        int value = entry , mod = 0 ;
        boolean [] return_value ;
        return_value = new boolean [5] ;
        for ( int index = 0 ; index < 5 ; index++ ) {
            mod = (value % 2) ;
            if ( mod == 0 )
                return_value [index] = false ;
            else
                return_value [index] = true ;
            value /= 2 ;
        }
        return return_value ;
    }
    
    public int convert_to_int ( boolean [] entry ) {    //KONTROL EDİLDİ : UYGUN
        int value = 0 ;
        for ( int index = 0 ; index < entry.length ; index++ ) {
            if ( entry [index] == true )
                value += (int) Math.pow ( 2 , index ) ;
        }
        return value ;
    }
        
    public boolean [] exor ( boolean [] x , boolean [] y ) {// KONTROL EDİLDİ : UYGUN  HATA DENETİMİ EKLE : EXOR LANACAK VERİLERİN UZUNLUĞU EŞİT OLMALI
        boolean[] exor_Value ;
        int length = x.length ;
        exor_Value = new boolean [length] ;
        for ( int index = 0 ; index < length ; index++ ) {
            if ( x [index] == y [index] ) {
                exor_Value [index] = false ;
            }
            else
                exor_Value [index] = true ;
        }
        
        return exor_Value ;
    }
    
    public boolean[] getKey() {
        return key;
    }

    public void setKey(boolean[] key) {
        this.key = key;
    }

    
    
    //GEÇİCİ FONKSİYONLAR: 
    
    
    public void find_ones ( boolean [] x) {
        System.out.println("x'in uzunluğu : " + x.length);
        for ( int index = 0 ; index < 48 ; index++ ) {
            if (x[index]==true)
                System.out.println("x["+index+"] : "+ "true");
        }
    }



    
    public void print_boolean_matrix ( boolean [] x ) {
        for ( int index = 0 ; index < x.length ; index++ ) {
            System.out.println("matris[" + index + "] = " + x[index] ) ;
        }
    }
        public void print_double_boolean_matrix ( boolean [] [] x ) {
            for ( int index = 0 ; index < x.length ; index++ ) {
                for ( int index2 = 0 ; index2 < x[0].length ; index2++ ) {
                    System.out.println("matris[" + index + "][" + index2 + "] = " + x[index][index2] ) ;
                }
            }
        }
}