package Algorithms;

public class Alphabet {
    char[] letters;
    String name;
    int length;
    
    public Alphabet (int lengthofalphabet, String name){
        this.name = name;
        length  = lengthofalphabet;
        letters = new char[lengthofalphabet];
        fill_alphabet();
    }
    
    private void fill_alphabet(){
        short index;
        short letter;
        
        if (this.name.equalsIgnoreCase("TÜRKÇE")){
                letters[0] = 'a'; letters[1] = 'b'; letters[2] = 'c'; letters[3] = 'ç'; letters[4] = 'd'; letters[5] = 'e'; letters[6] = 'f'; letters[7] = 'g'; letters[8] = 'ğ'; letters[9] = 'h'; letters[10] = 'ı'; letters[11] = 'i'; letters[12] = 'j'; letters[13] = 'k'; letters[14] = 'l'; letters[15] = 'm'; letters[16] = 'n'; letters[17] = 'o';letters[18] = 'ö'; letters[19] = 'p'; letters[20] = 'r'; letters[21] = 's'; letters[22] = 'ş'; letters[23] = 't'; letters[24] = 'u'; letters[25] = 'ü'; letters[26] = 'v'; letters[27] = 'y'; letters[28] = 'z';
        }
        
        if (this.name.equalsIgnoreCase("ENGLISH")){
            letter = 'a';
            for (index = 0; index < 26; index++){
                letters[index] = (char) letter;
                letter = (short) (letter + 1);
            }
        }
    }
    
/*GEÇİCİ*/    public void show_alphabet(){
        int a;
       for (int index = 0 ; index < letters.length ; index++){
           a = index+1;
            System.out.println("Alfabenin " + a + ". harfi = " + letters[index] + " ve " + "ascci değeri = " + (int) letters[index]);
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public char[] getLetters() {
        return letters;
    }

    public void setLetters(char[] letters) {
        this.letters = letters;
    }


    
}
