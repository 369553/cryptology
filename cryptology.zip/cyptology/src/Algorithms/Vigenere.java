package Algorithms;

public class Vigenere extends Ceasar{
    StringBuilder cipher_key;
    public static Vigenere vigenere ;
    int lengthOfKey = 0 ;

    public Vigenere(Alphabet alphabet) {
        super(alphabet);
    }
    
    public String crypting_main (String openMessage, String key, boolean state) {
        StringBuilder message, crypt_Message, report = new StringBuilder() ;
        if ( isReport == true && state == true )
            report.append( "-----\nŞİFRELEME RAPORLAMASI\nALGORİTMA: VIGENERE\nAÇIK METİN: " + openMessage + "\nANAHTAR: " + key + "\nAlfabe: " + getAlphabet().getName() + "\n\n********\n\n" ) ;
        int index, index2;
        this.cipher_key = new StringBuilder (key) ;
        char char_key;
        message = new StringBuilder (openMessage);
        crypt_Message = new StringBuilder ( openMessage ) ;
        for ( index = 0; index < message.length() ; index++ ) {
           char new_character =message.charAt(index);
            if ( new_character == ' ')
                crypt_Message.setCharAt(index, new_character) ;
            else {
                char_key = key.charAt(index) ;
                for ( index2 = 0 ; index2 < alphabet.letters.length ; index2++ ) {
                    if ( alphabet.letters[index2] == char_key ){
                        if ( state == true )
                            changeNumberofShift((short) index2); 
                        else
                            changeNumberofShift((short) -index2);
                        break;
                    }
                }
                    crypt_Message.setCharAt(index, shifting(message.charAt(index)));
                    if ( isReport == true && state == true )//BU YERİNE ŞU YAZILIRSA DAHA İYİ PERFORMANS MI: ( isReport && state )
                        report.append( ( index + 1 ) + ". karakter = " + new_character + " >> " + crypt_Message.charAt( index ) + "\n" ) ;
            }
        }
        if ( isReport == true && state == true ) {
            report.append( "\n\n********\n\nŞİFRELİ METİN: " + crypt_Message + "\n\nRapor Sonu." ) ;
            reportText = new String ( report ) ;
        }
        return new String (crypt_Message);
    }
    
    public String decrypting (String crypt_Message, String key) {
        return this.crypting_main (crypt_Message, key, false);
    }
    
    public String crypting ( String openMessage, String key ) {
        return this.crypting_main(openMessage, key, true);
    }

    public static Vigenere getVigenere() {
        if ( vigenere == null ) {
            vigenere = new Vigenere( new Alphabet( 29, "TÜRKÇE" ) ) ;
        }
        return vigenere;
    }
    
    public void setIsReport ( boolean value ) {
        super.isReport = value ;
        isReport = value ;
    }
    
    public String getReportText () {
        if ( reportText != null ) {
            return reportText ;
        }
        else
            return "Raporlama özelliği aktif edilmemiş" ;
    }
    
    public int getLengthofKey () {
        return lengthOfKey ;
    }
    
    public void setLengthofKey ( int x ) {
        lengthOfKey = x ;
    }
}
