package Algorithms;

public class Columnar {
    private static Columnar columnar ;
    static boolean isReport = false ;
    String reportText ;
    //ALGORİTMA EKSİKLİKLERİ: Rastgele sayı seçerken matris boyutu aynı olduğunda aynı rastgele sayıyı seçiyor. Çözmek için timer lazım galiba
    public char[][] crypting ( String open_Message ) {
        StringBuilder reporting = new StringBuilder() ;
        int index, index2, count=0;
        int[] size;
        char[][] double_array;
        if ( isReport == true )
            reporting.append( "-----\nŞİFRELEME RAPORLAMASI\nALGORİTMA: SÜTUN (COLUMNAR)\nAÇIK METİN: " + open_Message ) ;
        open_Message = deletespace( open_Message, open_Message.length() ) ;
        size = calculate_size ( open_Message.length() );
        if ( isReport == true ) 
            reporting.append( "\n\n********\n\n" + "Boşlukları silinmiş açık metin: " + open_Message + "\nHarf sayısı: " + open_Message.length() + "\nŞifreli metnin matris boyutu: " + ( size.length + 1 )+ "\n" ) ;
        double_array = new char[size[0]][size[1]];
        for ( index = 0 ; index < size[0] ; index++ ) {
            for ( index2 = 0 ; index2 < size[1] ; index2++ ) {
                if ( count < open_Message.length() ) {
                    double_array[index][index2] = open_Message.charAt(count);
                    if ( isReport == true )
                        reporting.append( "\nmatris[" + index + "][" + index2 + "] = " + open_Message.charAt( count ) + "(" + ( count + 1 ) + ". karakter)" ) ;
                    count++;
                }
                else
                    break;
            }
        }
        int left = ( size[0]*size[1] ) - count;
            while ( left!=0 ) {
                int random_char = ((size[0]*size[1])%50)+65+(open_Message.length()%3);
                double_array[size[0]-1][size[1]-left] = (char) random_char;
                if ( isReport == true )
                    reporting.append( "Boş kalan yerler dolduruluyor (matris[" + (size[0] -1) + "][" + (size[1]-left) + "] = " + ( (char) random_char + ")") ) ;
                left--;
            }
            if ( isReport == true ){
                reporting.append( "\nŞifreleme tamamlandı.\n\n********\n\n" ) ;
                reporting.append( "ŞİFRELİ METİN:\n" ) ;
                reporting.append( returnString(double_array) ) ;
                reporting.append( "\n\nRapor Sonu." ) ;
                reportText = new String( reporting ) ; 
            }
        return double_array;
    }

    
    public int[] calculate_size ( int length ) {
        int index;
        for ( index = 0 ; ; index++ ) {
            if ( length > index*index ) {
                if ( length <= ( (index+1) * (index+1) ) )
                    if ( ( (index+1) * (index+1) ) - length <index+1)
                    return new int[]{index+1,index+1};
                    else return new int[]{index,index+1};
            }
        }
    }
    
/*DENEME, SİL*/    public boolean display_shape_of_data ( String open_Message ) {
        int [] size;
        char [][] crypt_Message;
        crypt_Message = crypting ( open_Message ) ;
        size = calculate_size ( open_Message.length() );
        for ( int index = 0 ; index < size[0] ; index++ ) {
            System.out.print(index + "   ");
            System.out.print(crypt_Message[index]);
            System.out.println("\n");
        }
        return true;
    }
    
    public String decyrpting ( char[][] crypt_Message ) {
        StringBuilder openMessage = new StringBuilder(crypt_Message.length * crypt_Message[0].length);
        for (int index = 0 ; index < crypt_Message.length ; index++ ) {
            openMessage.append(crypt_Message[index]);
        }
        return new String(openMessage);
    }
    
    private String deletespace ( String text, int length ) {
        StringBuilder returnValue = new StringBuilder() ;
        char character ;
        int i=0 ;
        for ( i = 0 ; i < length ; i++ ) {
            character = text.charAt( i ) ;
            if ( character != ' ' ) {
                returnValue.append( character ) ;
            }
        }
        return new String( returnValue ) ;
    }

    public static Columnar getColumnar() {
        if ( columnar == null ) {
            columnar = new Columnar() ;
        }
        return columnar;
    }

    public static void setColumnar(Columnar columnar) {
        Columnar.columnar = columnar;
    }
    
    public String returnString ( char[][] doubleArray ) {
        StringBuilder value = new StringBuilder() ;
        for ( int i = 0 ; i < doubleArray.length ; i++ ) {
            value.append( doubleArray[i] ) ;
            if ( i+1 != doubleArray.length )
                value.append( "\n" ) ;
        }
        return new String ( value ) ;
    }
    
    public void setIsReport ( boolean value ) {
        isReport = value ;
    }
    
    public String getReportText() {
        if ( reportText != null ) {
            return reportText ;
        }
        else
            return "Raporlama özelliği aktif edilmemiş." ;
    }
    
}
