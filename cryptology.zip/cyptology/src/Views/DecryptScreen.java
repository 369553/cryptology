package Views;

import javax.swing.JPanel;

/**
 *
 * @author SOLAKOĞULLARI
 */
public class DecryptScreen extends JPanel {
    
}
