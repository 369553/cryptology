package Views;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JComponent;
import javax.swing.JPanel;

public class Add {
    public static Insets insets = new Insets(7,7,7,7);//Insets(5,5,5,5);
    
    private Add (){
        
    }
    
    public static void ADDCOMP (JPanel panel, JComponent comp, int x, int y, int width, int height, int location, int flexibility ) {
        GridBagConstraints ConVal = new GridBagConstraints();
        ConVal.gridx = x ;
        ConVal.gridy = y ;
        ConVal.gridwidth = width ;
        ConVal.insets = insets ;
        ConVal.gridheight = height ;
        ConVal.anchor = location; //GridBagConstraints.CENTER;
        ConVal.fill = flexibility; //GridBagConstraints.BOTH;
        panel.add(comp, ConVal );
    }
    
    /*public static void change_Insets(Insets insets) {
        int insets_number = insets.bottom;
        this.insets = insets ;
    }*/
}
