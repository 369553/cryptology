package Views;

import Algorithms.Ceasar;
import Base.SystemSettings;
import Control.CryptAction;
import Control.ChangeListen;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeListener;

public class ReqCeasar extends JPanel {
    JLabel Label_1st, Label_2nd ;
    JComboBox CBox_Lang ;
    JSlider Slider_1st ;
    CryptAction CryptAct ;
    ChangeListen changing ;
    
    public ReqCeasar() {
        setLayout( MainLayout.getMlayout() ) ;
        Add.ADDCOMP( this, getLabel_1st(), 1, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE ) ;
        Add.ADDCOMP( this, getSlider_1st(), 0, 1, 2, 2, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        Add.ADDCOMP( this, getLabel_2nd(), 0, 3, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        Add.ADDCOMP( this, getCBox_Lang(), 1, 3, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        //this.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.yellow, HEIGHT, true), "ds", WHEN_FOCUSED, HEIGHT, new Font("Times New Roman", Font.BOLD, 14), Color.yellow);
        this.setBorder( BorderFactory.createTitledBorder( "CEASAR" ) ) ;
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme() ) ;
        
    }




    public JSlider getSlider_1st() {
        if ( Slider_1st == null ) {
            Slider_1st = new JSlider(SwingConstants.HORIZONTAL, 1, Ceasar.getCeasar().getAlphabet().getLength() -1 , 1 ) ;
            Slider_1st.setMajorTickSpacing( 1 ) ;
            Slider_1st.setPaintTicks( true ) ;
            Slider_1st.addChangeListener( getchanging() ) ;
            Slider_1st.setPreferredSize( new Dimension( 180,38 ) ) ;
            Theme.AppTheme( Slider_1st, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Slider_1st;
    }

    public void setSlider_1st(JSlider Slider_1st) {
        this.Slider_1st = Slider_1st;
    }

    public JLabel getLabel_1st() {
        if ( Label_1st == null ) {
            Label_1st = new JLabel() ;
            NameandRenameLabel_1st() ;
            Theme.AppTheme( Label_1st, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Label_1st;
    }

    public void setLabel_1st(JLabel Label_1st) {
        this.Label_1st = Label_1st;
    }

    public JLabel getLabel_2nd() {
        if ( Label_2nd == null ) {
            Label_2nd = new JLabel( "Alfabe: " ) ;
            Theme.AppTheme( Label_2nd, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Label_2nd;
    }

    public void setLabel_2nd(JLabel Label_2nd) {
        this.Label_2nd = Label_2nd;
    }

    public JComboBox getCBox_Lang() {
        if ( CBox_Lang == null ) {
            CBox_Lang = new JComboBox ( new String[]{ "TÜRKÇE", "ENGLISH" } ) ;
            CBox_Lang.addActionListener( getCryptAct() ) ;
            Theme.AppTheme( CBox_Lang, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return CBox_Lang;
    }

    public void setCBox_Lang(JComboBox CBox_Lang) {
        this.CBox_Lang = CBox_Lang;
    }
    
    public void NameandRenameLabel_1st () {
        Label_1st.setText( Ceasar.getCeasar().getNum_shift() + " karakter kaydır" ) ;
    }

    public CryptAction getCryptAct() {
        if ( CryptAct == null ) {
            CryptAct = new CryptAction( this ) ;
        }
        return CryptAct;
    }

    public void setCryptAct(CryptAction CryptAct) {
        this.CryptAct = CryptAct;
    }
    
    public ChangeListen getchanging() {
        if ( changing == null ) {
            changing = new ChangeListen( this ) ;
        }
        return changing ;
    }
    public void changeSlider_1st () {
        Slider_1st.setMaximum( Ceasar.getCeasar().getAlphabet().getLength() -1 ) ;
    }

}