package Views;

import javax.swing.JPanel;


/**
 *
 * @author SOLAKOĞULLARI
 */
public class SpecDecryptScreen extends JPanel{
    
}
