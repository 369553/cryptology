package Views;

import Base.SystemSettings;
import Control.CryptAction;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JComboBox;

public class ReqPolybius extends JPanel{
    JLabel label1st ;
    JComboBox CBoxLang ;
    CryptAction CryptAct ;
    
    public ReqPolybius () {
        setLayout( MainLayout.getMlayout() ) ;
        
        
        
        this.setBorder( BorderFactory.createTitledBorder( "CEASAR" ) ) ;
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme() ) ;
    }

    public JLabel getLabel1st() {
        if ( label1st == null ) {
            label1st = new JLabel(" Alfabe:" ) ;
            Theme.AppTheme( label1st, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return label1st;
    }

    public void setLabel1st(JLabel label1st) {
        this.label1st = label1st;
    }

    public JComboBox getCBoxLang() {
        if ( CBoxLang == null ) {
            CBoxLang = new JComboBox( new String[]{ "TÜRKÇE", "ENGLISH" } ) ;
            CBoxLang.addActionListener( getCryptAct() ) ;
            Theme.AppTheme( CBoxLang, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return CBoxLang;
    }

    public void setCBoxLang(JComboBox CBoxLang) {
        this.CBoxLang = CBoxLang;
    }

    public CryptAction getCryptAct() {
        if ( CryptAct == null ) {
            CryptAct = new CryptAction ( this ) ;
        }
        return CryptAct;
    }

    public void setCryptAct(CryptAction CryptAct) {
        this.CryptAct = CryptAct;
    }
    
    
    
}
