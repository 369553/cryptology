package Base;

import Views.Theme;

/**
 *
 * @author SOLAKOĞULLARI
 */
public class SystemSettings {
    static boolean reports ;
    static String Language, ThemeName, PATHPosition ;
    static String [] Informations ;
    static Theme CurrentTheme ;
    private static SystemSettings settings;
    
    private SystemSettings ( String Language, String ThemeName , boolean reports ) {
        this.ThemeName = ThemeName ;
        this.Language = Language ;
        this.reports = reports ;
    }

    /*public String getLanguage() {
        if ( Language.equalsIgnoreCase( "ENGLISH" ) ) {
            DATABASE.ENGLISH ;
        }
        else if () ...
        return Language;
    }

    public void setLanguage(String Language) {
        this.Language = Language;
    }

    public String getBackgroundColor() {
        return BackgroundColor;
    }

    public void setBackgroundColor(String BackgroundColor) {
        this.BackgroundColor = BackgroundColor;
    }

    public String getPATHPosition() {
        return PATHPosition;
    }

    public void setPATHPosition(String PATHPosition) {
        this.PATHPosition = PATHPosition;
    }

    public String[] getInformations() {
        return Informations;
    }

    public void setInformations(String[] Informations) {
        this.Informations = Informations;
    }*/

    public static SystemSettings getSettings() {
        if (settings == null ) {
            settings = new SystemSettings("TÜRKÇE", "Blue", false ) ;
        }
        return settings;
    }

    public static boolean getIsReports() {
        if ( settings == null ) {
            getSettings();
        }
        return reports;
    }

    public static void setReports(boolean reports) {
        SystemSettings.reports = reports;
    }

    public static String getLanguage() {
        if ( settings == null ) {
            getSettings();
        }
        return Language;
    }

    public static void setLanguage(String Language) {
        SystemSettings.Language = Language;
    }

    public static String getThemeName() {
        if ( settings == null ) {
            getSettings();
        }
        return ThemeName;
    }

    public static void setThemeName (String ThemeName) {
        SystemSettings.ThemeName = ThemeName;
    }

    public static String getPATHPosition() {
        if ( settings == null ) {
            getSettings();
        }
        return PATHPosition;
    }

    public static void setPATHPosition(String PATHPosition) {
        SystemSettings.PATHPosition = PATHPosition;
    }

    public static Theme getCurrentTheme() {
        if ( CurrentTheme == null ) {
            CurrentTheme = new Theme( SystemSettings.getSettings().getThemeName() ) ;
        }
        return CurrentTheme;
    }

    public static void setCurrentTheme(Theme CurrentTheme) {
        SystemSettings.CurrentTheme = CurrentTheme;
    }
    
    
    
    @Override
    public String toString () {
        StringBuilder backValue = new StringBuilder() ;
        backValue.append( "Dil: " + getSettings().getLanguage() + "\nTema: " + getSettings().getThemeName() + "\nİpuçları göster: " ) ;
        backValue.append( "\nRaporla: " ) ;
        if (getSettings().getIsReports() == true )
            backValue.append ( "Evet" ) ;
        else
            backValue.append ( "Hayır" ) ;
        if (getSettings().getIsReports() == true )
            backValue.append( "\nDosya yolu: " + getSettings().getPATHPosition() ) ;
        return backValue.toString() ;
    }
    
}
